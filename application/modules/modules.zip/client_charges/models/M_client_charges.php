<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_client_charges extends CI_Model {

    public function __construct(){
        parent::__construct();
    }
}
?>