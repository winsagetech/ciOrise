
<section class="main-header" style="background-image:url(<?php echo base_url();  ?>assets/images/blogs/header.jpg)">

</section>


        <!-- ========================  Contact ======================== -->

        <section class="contact">

            <div class="container">

                <div class="row">

                    <div class="col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1">

                        <div class="contact-block">

                            <div class="contact-info">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <figure class="text-center">
                                            <span class="icon icon-cart"></span>
                                            <figcaption>
                                                <strong>Right Product</strong>                                                
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-sm-4">
                                        <figure class="text-center">
                                            <span class="icon icon-clock"></span>
                                            <figcaption>
                                                <strong>Right Time</strong>                                                
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-sm-4">
                                        <figure class="text-center">
                                            <span class="icon icon-tag"></span>
                                            <figcaption>
                                                <strong>Right Price</strong>                                                
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>

                            <div class="banner">
                                <div class="row">
                                    <div class="col-md-offset-1 col-md-10 text-center">
                                        <h2 class="title"><?php echo $product_name;?></h2>                                        
                                        <p>
                                            Please fill the form below to request your desired catalogue. <strong>Name, Email, Mobile & Country</strong>strong> are mandatory.
                                            For quick response please provide company name and address as well.
                                                                                         
                                        </p>
                                        <hr/>

                                        <div class="contact-form-wrapper">

                                            <!-- <a class="btn btn-clean open-form" data-text-open="Contact us via form" data-text-close="Close form">Contact us via form</a>  -->

                                            
                                                <form id="sendmail" name="sendmail" action="sendmail.php" method="post">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input id="Name" name="Name" type="text" value="" class="form-control" placeholder="Your name" >
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input id="Email" name="Email" type="email" value="" class="form-control" placeholder="Your email" >
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input id="Country" name="country" type="text" value="" class="form-control" placeholder="Country" >
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input id="Mobile" name="mobile" type="email" value="" class="form-control" placeholder="Mobile number" >
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <input id="Subject" name="Subject" type="text" value="" class="form-control" placeholder="" >
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <textarea id="Comment" name="Comment" class="form-control" placeholder="Your message" rows="10"></textarea>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12 text-center">
                                                            <input type="submit" class="btn btn-clean" value="Send message" />
                                                        </div>
                                                    </div>
                                                </form>
                                           
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="contact-info">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-4">
                                        <figure>
                                            <figcaption>
                                                <strong>Sales</strong>
                                                <span>
                                                    <strong>T</strong> +1 125 251 4586 <br />
                                                    <strong>F</strong> +1 251 333 5555
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-xs-6 col-sm-4">
                                        <figure>
                                            <figcaption>
                                                <strong>Services</strong>
                                                <span>
                                                    <strong>T</strong> +1 654 333 8541 <br />
                                                    <strong>F</strong> +1 125 251 5555
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-xs-6 col-sm-4">
                                        <figure>
                                            <figcaption>
                                                <strong>Support</strong>
                                                <span>
                                                    <strong>T</strong> +1 222 852 9632 <br />
                                                    <strong>F</strong> +1 357 333 5555
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-xs-6 col-sm-4">
                                        <figure>
                                            <figcaption>
                                                <strong>Human resources</strong>
                                                <span>
                                                    <strong>T</strong> +1 963 333 8745 <br />
                                                    <strong>F</strong> +1 159 333 5555
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-xs-6 col-sm-4">
                                        <figure>
                                            <figcaption>
                                                <strong>Factory</strong>
                                                <span>
                                                    <strong>T</strong> +1 753 333 1259 <br />
                                                    <strong>F</strong> +1 247 652 5555
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-xs-6 col-sm-4">
                                        <figure>
                                            <figcaption>
                                                <strong>Delivery</strong>
                                                <span>
                                                    <strong>T</strong> +1 134 197 7532 <br />
                                                    <strong>F</strong> +1 291 468 4563
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div><!--col-sm-8-->
                </div> <!--/row-->
            </div><!--/container-->
        </section>
