<?php

class Request extends MY_Controller {
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('product/M_product');
        $this->load->model('category/M_category');
        $this->load->model('orders/M_orders');
    }
    
    public function catalogue($id)
    {
        $data['product_name'] = $this->M_product->get_item_by_id($id)->name;
        
        $data['categories'] = $this->M_category->get_all_category();
        $data['products'] = $this->M_product->get_all_items();
        $this->load->view('template/header', $data);
        $this->load->view('catalogue_request_view', $data);
        $this->load->view('template/footer', $data);
    }
}
?>