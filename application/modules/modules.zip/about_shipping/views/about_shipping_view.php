
<section class="main-header" style="background-image:url(<?php echo base_url();  ?>assets/images/blogs/header.jpg)">
            <header>
                <div class="container text-center">
                    <h1 class="h2 title">ABOUT SHIPPING</h1>
                </div>
            </header>
</section>
        

<section class="history" id="page-about">
            <div class="container">

                <!-- === row item === -->

                <div class="row row-block">
                    <div class="col-md-12 history-desc">
        
                       <p >When you start to import from China, shipping is an essential thing to be concerned. You could choose the size according to your product volume.</p>

                        <p >20”GP container: 5.9*2.32*2.36m; Capacity: 25-28CBM; Payload:17.5 Ton</p>

                        <p >20”GP HEAVYcontainer: 5.9*2.32*2.36m; Capacity: 25-28CBM; Payload:upto 27 Ton</p>

                        <p >40” GP container: 11.6*2.32*2.36m; Capacity: 55-58CBM; Payload:22-25 Ton</p>

                        <p >40” HQ container: 11.6*2.32*2.68m; Capacity: 65-68CBM; Payload:22-25 Ton</p>

                        <p >45” GP container: 13.58*2.34*2.71m; Capacity: 78-86CBM; Payload:29-32Ton</p>

                        <p ><strong>The price quote in three ways normally-</strong></p>

                        <ol>
                          
                          <li><p >EXW (EX-works) price which only till the factory premises. Please check the following information for more regular terms: 1, EXW( Ex-works) You must arrange transportation all the way from factories/warehouse in Foshan to the destination port. And you are responsible for all export process.</p></ul>

                          <li><p >FOB ( Free on board) The FOB price includes EXW price, trucking charge, THC(terminal handling charge), customs cost. Normally the trucking charge and THC will be depending on total volume of the shipment. We will arrange cargo to nearby port, handling the export process. Your own forwarder will manage shipping from Port to your place.</p></ul>

                          <li><p >CIF( Cost , Insurance and Freight) We will arrange shipment to your port of destination. But you need to manage the shipment from destination port to your warehouse and handle the import process. For the detail cost, please contact us.</p></ul>

                        </ol>


                        <p >LCL( less than container load) and FCL (Full container load,including 20GP,40GP, 40HQ, 45GP) are both available</p>

                        <p >Due to big numbers of shipment every year to different part of the world we are shipping, we are well aware about all kind of shipments expects. Our team is specialized to give you the better solutions for your port with right time & choices.</p>

                        <p >Express/courier services- We help our clients to send the samples or goods by express/courier services as well in their breakeven prices.</p>

                        <p >One more tips for shipping: If you book the shipment & If the CIF price is at a very low price, please pay more attention. This is the method that forwarder use to attract customers. It will charge you a lot when picking up cargo at the port of destination. Normally the charge of destination port can be asked in advance</p>
                    </div>
                </div>
                
            </div>
</section>