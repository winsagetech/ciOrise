<?php
    
    class Fee extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('Fee/Fee_view');
        $this->load->view('template/footer');

    }
  }
?>