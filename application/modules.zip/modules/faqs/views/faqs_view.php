<section class="bg0 p-t-75 p-b-120" id="installation">
	<div class="container">
		<div class="p-b-32">
			<h3 class="ltext-105 cl5 txt-center respon1">Help & FAQs</h3>
		</div>

		
		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>What is Corian?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					It was designed to have the look of natural stone, but unlike granite or other stones, be entirely non-porous.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>What is Corian made of?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is a man-made product composed of 33 percent binding resins and 66 percent minerals. It is composed of acrylic polymer and alumina trihydrate (ATH), a material derived from bauxite ore.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Are Corian countertops durable?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is solid all the way through, making it extremely durable and a great choice for a countertop that will see heavy use. It is stain resistant, non-porous, and heat resistant.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Is Corian cheaper than granite?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is generally considered a mid-range priced countertop material. It is usually more affordably priced than granite, marble or quartz.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Is Corian cheaper than quartz?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is a reasonably priced countertop material that will usually be more affordable than quartz, granite, or marble.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>How much does Corian cost?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					The price range of Corian materials can vary depending on the color, texture or style you choose. Average prices range between $40 and $65 per square foot.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Is Corian scratch resistant?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian and solid surface materials are relatively soft compared to natural stone.  When you have Corian countertops, you should be careful to use cutting boards in the kitchen when preparing food. However, it is not difficult to repair using an orbital sander and fine grain sandpaper to sand down scratches.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Is Corian stain resistant?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is resistant to stains. It is essentially nonporous, meaning liquids cannot penetrate its surface, and also considered highly hygienic surface and easy to keep clean.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Can Corian countertops withstand heat?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is heat resistant and remains undamaged in temperatures up to 212ºF. However, as with all countertop materials, it is important to minimize direct heat exposure to protect your surface. Using heat pads is recommended.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Can Corian be sealed?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Unlike natural stone countertops like granite, Corian never requires sealing.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>Can you repair Corian countertops?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					Corian is a resilient material that allows for small scratches and chips to be sanded out of your countertop. Usually, this can be done DIY by the homeowner.</p>
				<br>
			</div>
		</div>

		<div class="row">

			<div class="col-md-12" padding="10px" class="">
				<div class="block1-info stext-102 trans-04 ">
					<h5>How do you clean Corian countertops?</h5><br>
				</div>

				<p align="justify" class="block1-info stext-102 trans-04 pad">
					According to the manufacturer RecCorian, for most Corian residues, all you need to clean your countertops is warm soapy water, ammonia-based household cleaner, or a dedicated countertop cleaner. Do avoid window cleaners, however, as they can leave a waxy build-up that dulls the surface.</p>
				<br>
			</div>
		</div>

		</div>		

		</div>
		</section>