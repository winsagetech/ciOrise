<?php

class M_details extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    function get_item($id)
    {
        $this->db->from('ci_idee_items');
        $this->db->where('srno', $id);
        $query = $this->db->get();
        return $query->row();
    }

    function get_review($id)
    {
        $this->db->from('ci_idee_review');
        $this->db->where('item_id', $id);
         $this->db->where('status', 'approved');
        $query = $this->db->get();
        return $query->result();
    }
    
    function get_item_category($id)
    {   
        $this->db->select('category');
        $this->db->from('ci_idee_items');
        $this->db->where('srno', $id);
        $query = $this->db->get();
        return $query->row();
    }

      public function add_review($data) {
        $this->db->insert('ci_idee_review', $data);
        return $this->db->insert_id();
    }
}
