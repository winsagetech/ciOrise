<?php

class Prod_details extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('prod_details/M_details');
        $this->load->model('inventory/M_inventory');
    }
    

    public function view_prod($id = '1', $cat)
    {
        //$data['review'] = $this->M_details->get_review($id);
        $data['product'] = $this->M_details->get_item($id);
        $category = $this->M_details->get_item_category($id)->category;
        $data['rel_prods'] = $this->M_inventory->get_items_from_category($category);
        $this->load->view('template/header', $data);
        $this->load->view('details_view', $data);
        $this->load->view('template/footer', $data);
    }
    public function add_review($id)
    {
         $data = array(
            'item_id'=> $id,
            'rating' => $this->input->post('rating'),
            'name' => $this->input->post('name'),
            'email' => $this->input->post('email'),
            'review' => $this->input->post('review')

            
        );
        $insert = $this->M_details->add_review($data);
        echo json_encode(array("status" => TRUE));
    }
    
}

?>