<?php

class Projects extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('projects/M_projects');
    }

    function index()
    {
        $data['projects'] = $this->M_projects->get_all_projects();
        $this->load->view('template/header', $data);
        $this->load->view('projects_view2', $data);
        $this->load->view('template/footer', $data);
    }

     function display_projects()
    {
        $this->load->library('session');
        $this->load->helper('url');
        if (! $this->session->userdata('user')) {
            redirect(base_url());
        } else {
            $data['project_types'] = $this->populate_project_select();
            
            $data['projects'] = $this->M_projects->get_all_projects_admin();
            $data['header'] = 'Projects';
            $data['page_desc'] = '';
            $data['content_view'] = 'projects/projects_view';
            $this->template->admin_template($data);
        }
    }

    function populate_project_select()
    {
        $item_types = $this->M_projects->get_project_types();
        $options = '';
        if (count($item_types)) {
            foreach ($item_types as $key => $value) {
                $options .= "<option value='{$value->id}'> {$value->title} </option>";
            }
        }
        return $options;
    }

     function upload_image( $file_name, $file_tmp)
    {
        if (isset($_FILES["project_image"])) {
           // $extension = explode('.', $_FILES['project_image']['name']);
            //$new_name = $_FILES['project_image']['name'];
            $destination = './assets/images/portfolio/' .  $file_name;
            unlink($destination);
            move_uploaded_file($file_tmp, $destination);
            return $file_name;
        }
    }

    public function image_add()
    {
        if(isset($_FILES['project_image'])){
    foreach($_FILES['project_image']['tmp_name'] as $key => $tmp_name ){
             $file_name = $key.$_FILES['project_image']['name'][$key];
           //  $file_size =$_FILES['files']['size'][$key];
             $file_tmp =$_FILES['project_image']['tmp_name'][$key];
        $data = array(
            'project_id' => $this->input->post('project'),
            
            'description' => $this->input->post('description'),
            'image' => $this->upload_image(  $file_name, $file_tmp)
            //'color' => $this->input->post('color')
        );
        $insert = $this->M_projects->image_add($data);
        
        echo json_encode(array(
            "status" => TRUE
        ));
    }}
    }

     public function project_add()
    {
        $data = array(
            'title' => $this->input->post('project_name'),
            
           // 'description' => $this->input->post('description'),
          //  'image' => $this->upload_image($this->input->post('description'))
            //'color' => $this->input->post('color')
        );
        $insert = $this->M_projects->project_add($data);
        
        echo json_encode(array(
            "status" => TRUE
        ));
    }

    public function project_delete($id)
    {
        $this->M_projects->delete_project_by_id($id);
        echo json_encode(array(
            "status" => TRUE
        ));
    }



    

}

?>