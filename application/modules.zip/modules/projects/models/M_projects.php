<?php

class M_projects extends CI_Model
{
    var $table_projects = 'ci_idee_projects';
    var $table_project_images = 'ci_idee_project_images';

    public function __construct()
    {
        parent::__construct();
    }

    function get_all_projects()
    {
        $this->db->select('*');
        $this->db->from($this->table_projects);
        $this->db->join($this->table_project_images, 'ci_idee_projects.id = ci_idee_project_images.project_id');
        $this->db->group_by("ci_idee_projects.id");
        $this->db->order_by("ci_idee_projects.id", 'ASC');
        $this->db->limit(6, 0);
        $query = $this->db->get();
        return $query->result();
    }

     function get_all_projects_admin()
    {
        $this->db->select('*');
        $this->db->from($this->table_projects);
        $query = $this->db->get();
        return $query->result();
    }

    function get_project_images($project_id)
    {
        $this->db->select('*');
        $this->db->from($table_project_images);
        $this->db->where('project_id', $project_id);
        $query = $this->db->get();
        return $query->result();
    }
     function get_project_types()
    {
        $query = $this->db->get('ci_idee_projects');
        return $query->result();
    }

     public function project_add($data)
    {
        $this->db->insert($this->table_projects, $data);
    }

    public function delete_project_by_id($id)
    {
        $this->db->where('id', $id);
        $this->db->delete($this->table_projects);
    }

     public function image_add($data)
    {
        $this->db->insert($this->table_project_images, $data);
    }
}
