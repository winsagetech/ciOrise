<script type="text/javascript"> var iid=0; var invoiceid=0;var stoneprice;var diamondprice;var drate;</script>
<div class="row">
	<div class="col-md-2 pull-right">
		<button class="btn btn-warning  pull-right" onclick="add_project()">
			<i class="fa fa-plus-circle"></i> &nbsp; &nbsp; Add Project
		</button>
	</div>
	<div class="col-md-2 pull-right">
		<button class="btn btn-warning  pull-right" onclick="add_image()">
			<i class="fa fa-plus-circle"></i> &nbsp; &nbsp; Add Image
		</button>
	</div>
</div>
<br>
<div class="box">
	<!-- /.box-header -->
	<div class="box-body">
		<table id="table_id" class="table table-striped table-bordered">
			<thead>

				<th>Id</th>
				<th>Project Name</th>
				<th>Action</th>
			</thead>
			<tbody>
            <?php foreach($projects as $project){?>

                    <td><?php echo $project->id;?></td>
				<td><?php echo $project->title;?></td>

				<td align="center">
					<button class="btn btn-warning" title="Edit"
						onclick="edit_item_user(<?php echo $project->id;?>)">
						<i class="fa fa-edit"></i>
					</button>
					<button class="btn btn-danger" title="Delete"
						onclick="delete_project(<?php echo $project->id;?>)">
						<i class="fa fa-trash"></i>
					</button>
				</td>

				</tr>
            <?php }?>
            </tbody>
			<tfoot>
				<tr>
				<th>Id</th>
				<th>Project Name</th>
				<th>Action</th>
				</tr>
			</tfoot>
		</table>

	</div>
	<!-- box body -->
</div>
<!-- box -->


<!-- jQuery 3 -->
<script
	src="<?php echo base_url();  ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script
	src="<?php echo base_url();  ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Data Tables -->
<script
	src="<?php echo base_url();  ?>assets/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script
	src="<?php echo base_url();  ?>assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script
	src="<?php echo base_url();  ?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script
	src="<?php echo base_url();  ?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();  ?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();  ?>assets/dist/js/demo.js"></script>
<!-- Barcode -->
<script src="<?php echo base_url();  ?>assets/dist/js/barcode.min.js"></script>
<!-- Generate PDF
<script src="<?php echo base_url();  ?>assets/dist/js/png.js"></script>
<script src="<?php echo base_url();  ?>assets/dist/js/zlib.js"></script>
<script src="<?php echo base_url();  ?>assets/dist/js/jspdf.min.js"></script>

<script src="<?php echo base_url();  ?>assets/dist/js/html2canvas.js"></script>
-->



<script type="text/javascript">
    $(document).ready( function () {
        $('#table_id').DataTable();
    } );


    var save_method; //for save method string
    var invoice_type;
    var table;

    function add_project() {
        save_method = 'add';
        //$('#components_input_admin').show();
        $('#form')[0].reset(); // reset form on modals
        $('#modal_project').modal('show'); // show bootstrap modal
      //  document.getElementById('itemid').value=iid + 1;
    }

     function add_image() {
        save_method = 'image';
        //$('#components_input_admin').show();
        $('#form_image')[0].reset(); // reset form on modals
        $('#modal_image').modal('show'); // show bootstrap modal
      //  document.getElementById('itemid').value=iid + 1;
    }

     
   function edit_item(id) {
        save_method = 'update';
        $('#form')[0].reset(); // reset form on modals

        //Ajax Load data from ajax
        $.ajax({
            url : "<?php echo site_url('projects/ajax_edit_item/')?>/" + id,
            type: "GET",
            dataType: "JSON",
            success: function(data) {
                $('[name="date"]').val(data.item.date);
                $('[name="sr_num"]').val(data.item.srno);
                $('[name="item"]').val(data.item.image);
                $('[name="item_name"]').val(data.item.name);
                $('[name="item_model"]').val(data.item.category);                
                $('[name="color"]').val(data.item.color);

                $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
                $('.modal-title').text('Edit Item'); // Set title to Bootstrap modal title
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert('Error get data from ajax');
            }
        });
    }

 
    function save() {
        var url;
        if(save_method == 'add') {
            url = "<?php echo site_url('projects/project_add/');?>" ;
             var item_form = document.getElementById("form");
        } else if(save_method == 'image') {
            url = "<?php echo site_url('projects/image_add/'); ?>" ;
            var item_form = document.getElementById("form_image");
        } else {
            url = "<?php echo site_url('projects/item_update'); ?>";
        }
        //console.log('Form Data ' + $('#form').serialize());
       
        //var disabled = $('#form').find(':input:disabled').removeAttr('disabled');
        $.ajax({
            url: url,
            type: "POST",
            data: new FormData(item_form),
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(data) {
                //if success close modal and reload ajax table
                //saveImage();
                $('#modal_form').modal('hide');
                location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(errorThrown);
                alert('Error adding / update data');
              //  disabled.attr('disabled','disabled');
            }
        });
    }

    function delete_project(id) {
        if(confirm('Are you sure delete this data?')) {
            // ajax delete data from database
            $.ajax({
                url : "<?php echo site_url('projects/project_delete')?>/"+id,
                type: "POST",
                dataType: "JSON",
                success: function(data) {
                    location.reload();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert('Error deleting data');
                }
            });
        }
    }

    
</script>

<!-- Bootstrap modal -->
<div class="modal fade" id="modal_project" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"
					aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h3 class="modal-title">Project Add</h3>
			</div>
			<div class="modal-body form">
				<form action="#" id="form" class="form-horizontal"
					enctype="multipart/form-data">
					<div class="form-body">
						<div class="form-group">
							<label class="control-label col-md-3">Project Name</label>
							<div class="col-md-9">
								<input type="text" name="project_name" class="form-control"
									id="project_name">
							</div>
						</div>
						<hr>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" id="btnSave" onclick="save()"
					class="btn btn-primary">Save</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- End Bootstrap modal -->

<div class="modal fade" id="modal_image" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"
					aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h3 class="modal-title">Item Form</h3>
			</div>
			<div class="modal-body form">
				<form action="#" id="form_image" class="form-horizontal"
					enctype="multipart/form-data">
					<input type="hidden" value="" name="id" />
					<div class="form-body">
						<div class="form-group">
							<label class="control-label col-md-3">Select Project</label>
							<div class="col-md-9">
								<select name="project" class="form-control select2">
                                    <?php echo $project_types; ?>
                                </select>
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3">Image</label>
							<div class="col-md-9">
								<input type="file" name="project_image[]" id="project_image" multiple="multiple">
							</div>
						</div>
						<div class="form-group">
							<label class="control-label col-md-3">Description</label>
							<div class="col-md-9">
								<div class="col-md-9">
								<input type="text" name="description" class="form-control"
									id="description">
							</div>
							</div>
						</div>


						<hr>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" id="btnSave" onclick="save()"
					class="btn btn-primary">Save</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
			</div>
		</div>
		<!-- /.modal-content -->
	</div>
	<!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<!-- End Bootstrap modal -->


