 <div class="page-loader"></div>
        <section class="main-header" style="background-image:url(<?php echo base_url() ?>/assets/mobel/assets/images/ourstory_image1.jpg)">
            <header>
                <div class="container text-center">
                    <h1 class="h2 title">Projects</h1>
                </div>
            </header>
        </section>
<br>
<br>
<!-- Products -->
 <section class="products">
	<div class="container">
		
    	<?php
    $prev_cat = "";
    $cur_cat = "";
    $gallery_started = FALSE;
    $a=1;
    foreach ($gallery as $gallery_item) {
        $cur_cat = $gallery_item->category;
        if ($cur_cat !== $prev_cat) {
            $prev_cat = $cur_cat;
            if ($gallery_started === TRUE) {
                echo '</div></div>';
                $gallery_started = FALSE;
            }
            
            ?>
        			<div id="section-cat-<?php echo $a;?>">
				<h3 class="ltext-105 cl5 txt-center respon1"> <?php echo $cur_cat; ?> </h3>
			</div>
			<div class="products">
			<div class="row ">
        	        <?php $gallery_started = TRUE; ?>
        

                            <!-- === product-item === -->

                            <div class="col-md-4 col-xs-4">

                                <article>
                                    <div class="figure-grid">
                                        <div class="image">
                                            <a href="#productid-<?php echo $gallery_item->srno;?>" class="mfp-open">
                                                <img src="<?php echo base_url() . 'upload/' . $gallery_item->image;?>" alt="" width="360" />
                                            </a>
                                        </div>
                                        <div class="text">
                                            <h2 class="title h4"><a href="<?php echo base_url();  ?>prod_details/view_prod/<?php echo $gallery_item->srno;?>/<?php echo $gallery_item->category;?>"><?php echo $gallery_item->name; ?></a></h2>
                                        </div>
                                    </div>
                                </article>
                            </div>

        	        
        <?php $a++; } else { ?>	    
        	          <div class="col-md-4 col-xs-4">

                                <article>
                                    <div class="figure-grid">
                                        <!--span class="label label-info">-50%</span-->
                                        <div class="image">
                                            <a href="#productid-<?php echo $gallery_item->srno;?>" class="mfp-open">
                                                <img src="<?php echo base_url() . 'upload/' . $gallery_item->image;?>" alt="" width="360" />
                                            </a>
                                        </div>
                                          <div class="text">
                                             <h2 class="title h4"><a href="<?php echo base_url();  ?>prod_details/view_prod/<?php echo $gallery_item->srno;?>/<?php echo $gallery_item->category;?>"><?php echo $gallery_item->name; ?></a></h2>
                                         </div>
                                    </div>
                                </article>
                            </div>

        	    <?php
        }
    }
    
    ?>

			</div>
	</div>
<?php 
foreach ($gallery as $gallery_item) { ?>
    <div>
                <div class="popup-main mfp-hide" id="productid-<?php echo $gallery_item->srno;?>" >

                    <!-- === product popup === -->

                    <div class="product" >

                        <!-- === popup-title === -->

                        <div class="popup-title">
                            <div class="h1 title"><?php echo $gallery_item->name; ?><small><?php echo $gallery_item->category;?></small></div>
                        </div>

                        <!-- === product gallery === -->

                        <div class="owl-product-gallery">
                            <img src="<?php echo base_url() . 'upload/' . $gallery_item->image;?>" alt="" width="640" />
                        </div>

                        <!-- === product-popup-info === -->

                      
                        <!-- === product-popup-footer === -->

                        <!--div class="popup-table">
                            <div class="popup-cell">
                                <div class="price">
                                    <span class="h3">$ 1999,00 <small>$ 2999,00</small></span>
                                </div>
                            </div>
                            <div class="popup-cell">
                                <div class="popup-buttons">
                                    <a href="product.html"><span class="icon icon-eye"></span> <span class="hidden-xs">View more</span></a>
                                    <a href="javascript:void(0);"><span class="icon icon-cart"></span> <span class="hidden-xs">Buy</span></a>
                                </div>
                            </div>
                        </div-->

                    </div> <!--/product-->
                </div> <!--popup-main-->
     </div>
           <?php } ?>
                  </div>
              </section>