<?php

class Dashboard extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->module([
            'inventory',
           'projects',
          //  'a_configure',
            'login',
            'category',
         //   'accounts',
        //    'payments',
        //  'invoice',
            //'pages',
          //  'orders',
            'blog',
         //   'career',
          //  'review',
            'subscribers'
        ]);
        $this->load->model('projects/M_projects');
      //  $this->load->model('users/M_users');
      //  $this->load->model('a_configure/M_config');
        $this->load->model('category/M_category');
      //  $this->load->model('accounts/M_accounts');
      //  $this->load->model('payments/M_payments');
      //  $this->load->model('invoice/M_invoice');
      // $this->load->model('review/M_review');
        $this->load->model('blog/M_blog');
     //   $this->load->model('career/M_career');
    //    $this->load->model('orders/M_orders');
        $this->load->model('subscribers/M_subscribers');
    }

    function index()
    {
        $this->load->library('session');
        $this->load->helper('url');
        if (! $this->session->userdata('user')) {
            redirect(base_url());
        } else if ($this->session->userdata('user') != "admin") {
            redirect('dashboard/inventory');
        } else {
            
            $data['header'] = 'Dashboard';
            $data['page_desc'] = 'Overalls';
            $data['content_view'] = 'dashboard/dashboard_v';
            $data['item_count'] = $this->M_inventory->get_items_count();
           // $data['makers_count'] = $this->M_users->get_makers_count();
          //  $data['clients_count'] = $this->M_users->get_clients_count();
          //  $data['payment'] = $this->M_payments->get_total_payment();
         //   $p = $this->M_payments->get_total_payment();
         //   $o = $this->M_payments->get_outstanding();
         //   $data['outstanding'] = $o - $p;
            $this->template->admin_template($data);
        }
    }

    function inventory()
    {
        $this->inventory->display_items();
    }

  /*  function users()
    {
        $this->users->display_users();
    }*/

   
    function categories()
    {
        $this->category->display_category();
    }

    function projects()
    {
      $this->projects->display_projects();
    }

   // function pages()
   // {
   //     $this->pages->display_Pages();
  //  }

   // function invoices()
  //  {
  //      $this->invoice->display_invoice();
   // }

   // function orders()
   // {
   //     $this->orders->display_orders();
//}

    function blogs()
    {
        $this->blog->display_blog();
    }

   // function reviews()
   // {
     //   $this->review->display_review();
   // }

   // function career()
    //{
     //   $this->career->display_career();
    //}
    
    function subscribers()
    {
        $this->subscribers->display_subscribers();
    }
}

?>