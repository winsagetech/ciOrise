 <div class="page-loader"></div>
        <section class="main-header" style="background-image:url(<?php echo base_url() ?>assets/images/gallery.jpg)">
            <header>
                <div class="container text-center">
                    <h1 class="h2 title">Products</h1>
                </div>
            </header>
        </section>
<br>
<br>
<!-- Products -->
 <section class="products">
	<div class="container">
		
    	<?php
    $prev_cat = "";
    $cur_cat = "";
    $gallery_started = FALSE;
    $a=1;
    foreach ($gallery as $gallery_item) {
        $cur_cat = $gallery_item->category;
        if ($cur_cat !== $prev_cat) {
            $prev_cat = $cur_cat;
            if ($gallery_started === TRUE) {
                echo '</div></div>';
                $gallery_started = FALSE;
            }
            
            ?>
        	<div id="section-cat-<?php echo $a;?>">
				<h3 class="ltext-105 cl5 txt-center respon1"> <?php echo $cur_cat; ?> </h3>
			</div>
			<div class="products">
			<div class="row ">
        	        <?php $gallery_started = TRUE; ?>
        

                            <!-- === product-item === -->

                            <div class="col-md-4 col-xs-4">

                                <article>
                                    <div class="figure-grid">
                                        <div class="image">
                                            <a href="<?php echo base_url();  ?>prod_details/view_prod/<?php echo $gallery_item->srno;?>/<?php echo $gallery_item->category;?>">
                                            
                                            <img src="<?php echo base_url() . 'upload/' . $gallery_item->image;?>" alt="" width="360" />
                                            </a>
                                        </div>

                                        <div class="text">
                                            <h2 class="title h4"><a href="<?php echo base_url();  ?>prod_details/view_prod/<?php echo $gallery_item->srno;?>/<?php echo $gallery_item->category;?>"><?php echo $gallery_item->name; ?></a></h2>
                                        </div>
                                    </div>
                                </article>
                            </div>

        	        
        <?php $a++; } else { ?>	    
        	          <div class="col-md-4 col-xs-4">

                                <article>
                                    <div class="figure-grid">
                                        <!--span class="label label-info">-50%</span-->
                                        <div class="image">
                                            <a href="<?php echo base_url();  ?>prod_details/view_prod/<?php echo $gallery_item->srno;?>/<?php echo $gallery_item->category;?>">
                                            
                                            <img src="<?php echo base_url() . 'upload/' . $gallery_item->image;?>" alt="" width="360" />
                                            </a>
                                        </div>
                                          <div class="text">
                                             <h2 class="title h4"><a href="<?php echo base_url();  ?>prod_details/view_prod/<?php echo $gallery_item->srno;?>/<?php echo $gallery_item->category;?>"><?php echo $gallery_item->name; ?></a></h2>
                                         </div>
                                    </div>
                                </article>
                            </div>

        	    <?php
        }
    }
    
    ?>

			</div>
	</div>

                  </div>
              </section>