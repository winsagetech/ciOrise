<?php

class Gallery extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('gallery/M_gallery');
    }

    function index()
    {
        $data['gallery'] = $this->M_gallery->get_all_items();
        $this->load->view('template/header', $data);
        $this->load->view('gallery_view2', $data);
        $this->load->view('template/footer', $data);
    }
}

?>