<?php
    
    class About extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('about/about_view');
        $this->load->view('template/footer');

    }
  }
?>