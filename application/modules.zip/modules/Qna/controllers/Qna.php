<?php
    
    class Qna extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('qna/qna_view');
        $this->load->view('template/footer');

    }
  }
?>