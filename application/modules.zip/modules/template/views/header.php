<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Mobile Web-app fullscreen -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">

    <!-- Meta tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <!--Title-->
    <title>OriseChina</title>

    <!--CSS styles-->
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/bootstrap.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/animate.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/font-awesome.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/furniture-icons.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/linear-icons.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/magnific-popup.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/owl.carousel.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/ion-range-slider.css" />
    <link rel="stylesheet" media="all" href="<?php echo base_url();  ?>assets/mobel/css/theme.css" />


    <!--Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600&amp;subset=latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="page-loader"></div>

    <div class="wrapper">

        <!-- ======================== Navigation ======================== -->

        <nav class="navbar-fixed navbar-single-page">

            <div class="container">

                <!-- ==========  Top navigation ========== -->

                <div class="navigation navigation-top clearfix">
                    <ul>
                        <!--add active class for current page-->
                        <li><a href="https://www.facebook.com/Interiors-IDEE-288351034559998/"><i class="fa fa-facebook"></i></a></li>
                                <!--  
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                 -->
                        <li><a href="https://www.instagram.com/idee.interiors/"><i class="fa fa-instagram"></i></a>
                    </ul>
                </div>

                <!-- ==========  Main navigation ========== -->

                <div class="navigation navigation-main">
                    <div class="open-menu"><i class="icon icon-menu"></i></div>
                    <div class="floating-menu">
                        <!--mobile toggle menu trigger-->
                        <div class="close-menu-wrapper">
                            <span class="close-menu"><i class="icon icon-cross"></i></span>
                        </div>
                        <ul>
                            <li><a href="<?php echo base_url();  ?>#page-home" class="current">Home</a></li>
                            <li>
                                <a href="<?php echo base_url();  ?>#page-projects">Products <span class="open-dropdown"><i class="fa fa-angle-down"></i></span></a>
                                <div class="navbar-dropdown">
                                    <div class="navbar-box">

                                        <div class="box-2">
                                            <div class="clearfix categories">
                                                <div class="row">

                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-sofa"></i>
                                                                <figcaption>Furniture</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-lightning"></i>
                                                                <figcaption>Lights</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>

                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-kitchen"></i>
                                                                <figcaption>Marble & Granite</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-bar-set" ></i>
                                                                <figcaption>Banquet & Buffet Display</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-wardrobe"></i>
                                                                <figcaption>Wallpaer </figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-carpet"></i>
                                                                <figcaption>Wooden Flooring</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-kitchen"></i>
                                                                <figcaption>Sanitry Ware</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-bathroom"></i>
                                                                <figcaption>Bathroom Fittings</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-bathroom"></i>
                                                                <figcaption>Door & Windows</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-shoe-cabinet"></i>
                                                                <figcaption>Facade Items</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-wardrobe"></i>
                                                                <figcaption>Acoustic</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-bar-set"></i>
                                                                <figcaption>Hotel Operational Items</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-bookcase"></i>
                                                                <figcaption>Painting & Show Pieces</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>

                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-carpet"></i>
                                                                <figcaption>Carpet</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                    <!--icon item-->                                                

                                                    <div class="col-sm-3 col-xs-6">
                                                        <a href="javascript:void(0);">
                                                            <figure>
                                                                <i class="f-icon f-icon-accessories"></i>
                                                                <figcaption>Accessories & Othersss</figcaption>
                                                            </figure>
                                                        </a>
                                                    </div>
                                                    
                                                </div> <!--/row-->
                                            </div> <!--/categories-->
                                        </div> <!--/box-2-->
                                    </div> <!--/navbar-box-->
                                </div> <!--/navbar-dropdown-->
                            </li>
                                                        <li>
                                <a href="#">Products <span class="open-dropdown"><i class="fa fa-angle-down"></i></span></a>
                                <div class="navbar-dropdown">
                                    <div class="navbar-box">
                                        <div class="box-2">
                                            <div class="box clearfix">
                                                <div class="row">
                                                    <div class="clearfix">
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Seating</li>
                                                                <li><a href="javascript:void(0);">Benches</a></li>
                                                                <li><a href="javascript:void(0);">Submenu <span class="label label-warning">New</span></a></li>
                                                                <li><a href="javascript:void(0);">Chaises</a></li>
                                                                <li><a href="javascript:void(0);">Recliners</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Storage</li>
                                                                <li><a href="javascript:void(0);">Bockcases</a></li>
                                                                <li><a href="javascript:void(0);">Closets</a></li>
                                                                <li><a href="javascript:void(0);">Wardrobes</a></li>
                                                                <li><a href="javascript:void(0);">Dressers <span class="label label-success">Trending</span></a></li>
                                                                <li><a href="javascript:void(0);">Sideboards </a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Tables</li>
                                                                <li><a href="javascript:void(0);">Consoles</a></li>
                                                                <li><a href="javascript:void(0);">Desks</a></li>
                                                                <li><a href="javascript:void(0);">Dining tables</a></li>
                                                                <li><a href="javascript:void(0);">Occasional tables</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Chairs</li>
                                                                <li><a href="javascript:void(0);">Dining Chairs</a></li>
                                                                <li><a href="javascript:void(0);">Office Chairs</a></li>
                                                                <li><a href="javascript:void(0);">Lounge Chairs <span class="label label-warning">Offer</span></a></li>
                                                                <li><a href="javascript:void(0);">Stools</a></li>

                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix">
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Kitchen</li>
                                                                <li><a href="javascript:void(0);">Kitchen types</a></li>
                                                                <li><a href="javascript:void(0);">Kitchen elements <span class="label label-info">50%</span></a></li>
                                                                <li><a href="javascript:void(0);">Bars</a></li>
                                                                <li><a href="javascript:void(0);">Wall decoration</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Accessories</li>
                                                                <li><a href="javascript:void(0);">Coat Racks</a></li>
                                                                <li><a href="javascript:void(0);">Lazy bags <span class="label label-success">Info</span></a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Beds</li>
                                                                <li><a href="javascript:void(0);">Beds</a></li>
                                                                <li><a href="javascript:void(0);">Sofabeds</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Entertainment</li>
                                                                <li><a href="javascript:void(0);">Wall units <span class="label label-warning">Popular</span></a></li>
                                                                <li><a href="javascript:void(0);">Media sets</a></li>
                                                                <li><a href="javascript:void(0);">Decoration</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> <!--/box-->
                                        </div> <!--/box-2-->
                                    </div> <!--/navbar-box-->
                                </div> <!--/navbar-dropdown-->
                            </li>
                            

<!--                             <li>
                                <a href="#">Product_2 <span class="open-dropdown"><i class="fa fa-angle-down"></i></span></a>
                                <div class="navbar-dropdown">
                                    <div class="navbar-box">
                                        <div class="box-2">
                                            <div class="box clearfix">
                                                <div class="row">
                                                    <div class="clearfix">
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Furniture</li>
                                                                <li><a href="javascript:void(0);">Hotel Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Home Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Outdoor Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Restrorant & Bar Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Hospital Furniture</a></li>
                                                                <li><a href="javascript:void(0);">School & University Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Indoor & Outdoor Play Equipment Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Banquet Furniture</a></li>
                                                                <li><a href="javascript:void(0);">Office & Partion Furniture</a></li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Light</li>
                                                                <li><a href="javascript:void(0);">LED Strip</a></li>
                                                                <li><a href="javascript:void(0);">Indoor</a></li>
                                                                <li><a href="javascript:void(0);">Outdoor</a></li>
                                                                <li><a href="javascript:void(0);">Custom Made Chandelier </a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Marble & Granite</li>
                                                                <li><a href="javascript:void(0);">Marble Block</a></li>
                                                                <li><a href="javascript:void(0);">Marble Slab</a></li>
                                                                <li><a href="javascript:void(0);">Granite</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Banquet & Buffet Display</li>
                                                                <li><a href="javascript:void(0);">Live Counters</a></li>
                                                                <li><a href="javascript:void(0);">Display Accessories</a></li>
                                                                <li><a href="javascript:void(0);">Display Racks & Tables</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Wallpaper</li>
                                                                <li><a href="javascript:void(0);">Wallpaper</a></li>
                                                                <li><a href="javascript:void(0);">Wallpaper Covering</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Wooden Flooring</li>
                                                                <li><a href="javascript:void(0);">Laminated Floor</a></li>
                                                                <li><a href="javascript:void(0);">Engineer Wood Flooring</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Sanitry Ware</li>
                                                                <li><a href="javascript:void(0);">Bath tub & Shower Enclouser</a></li>
                                                                <li><a href="javascript:void(0);">WC & Basin</a></li>
                                                            </ul>
                                                        </div>

                                                        

                                                        
                                                    </div>
                                                    <div class="clearfix">

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Bathroom Fittings</li>
                                                                <li><a href="javascript:void(0);">Bathroom Accessories</a></li>
                                                                <li><a href="javascript:void(0);">Bathroom Cabinets</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Doors & Windows</li>
                                                                <li><a href="javascript:void(0);">Steel & Wooden Doors</a></li>
                                                                <li><a href="javascript:void(0);">Aluminium Doors & Windows</a></li>
                                                                <li><a href="javascript:void(0);">UPVC Doors & Windows</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Facade Items</li>
                                                                <li><a href="javascript:void(0);">Aluminium Facade</a></li>
                                                                <li><a href="javascript:void(0);">Glass Facade</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Acoustic</li>
                                                                <li><a href="javascript:void(0);">Acoustic Panel</a></li>
                                                                <li><a href="javascript:void(0);">Banquet Partition</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Hotel Operational Items</li>
                                                                <li><a href="javascript:void(0);">Safe Minibar & Wine Chiller</a></li>
                                                                <li><a href="javascript:void(0);">Room Folder & Ice Bucket</a></li>
                                                                <li><a href="javascript:void(0);">Hotel Trolley</a></li>
                                                                <li><a href="javascript:void(0);">Dustbin</a></li>
                                                                <li><a href="javascript:void(0);">Other Accessories</a></li>
                                                            </ul>
                                                        </div>

                                                         <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Paintings & Show pieces</li>
                                                                <li><a href="javascript:void(0);">Abstract Paintings</a></li>
                                                                <li><a href="javascript:void(0);">Art Effective & Decorative Peices</a></li>
                                                            </ul>
                                                        </div>


                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Carpet</li>
                                                                <li><a href="javascript:void(0);">Designer Carpet</a></li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-3">
                                                            <ul>
                                                                <li class="label">Accessories & Others</li>
                                                                <li><a href="javascript:void(0);">Air Conditioner Accessories</a></li>
                                                                <li><a href="javascript:void(0);">Car Accessories</a></li>
                                                                <li><a href="javascript:void(0);">Others</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                    </div> 
                                </div> 
                            </li> -->
                            
                            <!-- <li><a href="<?php echo base_url();  ?>#page-whyus">WHY US?</a></li> -->
                            <li>
                                <a href="<?php echo base_url();  ?>why_us">WHY US? <span class="open-dropdown"><i class="fa fa-angle-down"></i></span></a>
                                <div class="navbar-dropdown navbar-dropdown-single">
                                    <div class="navbar-box">

                                        <!-- box-2 (without 'box-1', box-2 will be displayed as full width)-->

                                        <div class="box-2">
                                            <div class="box clearfix">
                                                <ul>
                                                    <li><a href="<?php echo base_url();  ?>#page-whoweare">WHO WE ARE</a></li>
                                                    <li><a href="<?php echo base_url();  ?>#page-whoneedus">WHO NEED US</a></li>
                                                </ul>
                                            </div> <!--/box-->
                                        </div> <!--/box-2-->
                                    </div> <!--/navbar-box-->
                                </div> <!--/navbar-dropdown-->
                            </li>
                            <!-- <li><a href="<?php echo base_url();  ?>#page-howtodo">HOW TO DO?</a></li> -->
                            <li>
                                <a href="<?php echo base_url();  ?>#page-howtodo">HOW TO DO? <span class="open-dropdown"><i class="fa fa-angle-down"></i></span></a>
                                <div class="navbar-dropdown navbar-dropdown-single">
                                    <div class="navbar-box">

                                        <!-- box-2 (without 'box-1', box-2 will be displayed as full width)-->

                                        <div class="box-2">
                                            <div class="box clearfix">
                                                <ul>
                                                    <li><a href="<?php echo base_url();  ?>our_services">OUR SERVICES</a></li>
                                                    <li><a href="<?php echo base_url();  ?>fee">FEE</a></li>
                                                    <li><a href="<?php echo base_url();  ?>client_charges">CLIENT CHARGES</a></li>
                                                    <li><a href="<?php echo base_url();  ?>qna">Q & A</a></li>
                                                    <li><a href="<?php echo base_url();  ?>about_shipping">ABOUT SHIPPING</a></li>
                                                    
                                                </ul>
                                            </div> <!--/box-->
                                        </div> <!--/box-2-->
                                    </div> <!--/navbar-box-->
                                </div> <!--/navbar-dropdown-->
                            </li>
                            <li><a href="<?php echo base_url();  ?>about">About</a></li>                            
                            <li><a href="<?php echo base_url();  ?>#page-contact">Contact</a></li>
                            <li><a href="<?php echo base_url();  ?>blog">Blog</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </nav>