<h1>This is the main template</h1>
<?php $this->load->view($content_view); ?>