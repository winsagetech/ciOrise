

<section class="bg0 p-t-100 p-b-50" id="application">
	<div class="container">
		<div class="p-b-32">
			<h3 class="ltext-105 cl5 txt-center respon1">Application</h3>
		</div>

		<div class="flex-w flex-sb-m p-b-52">
			<div class="flex-w flex-l-m filter-tope-group m-tb-10">
				<button
					class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5 how-active1"
					data-filter="*">All</button>

				<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
					data-filter=".business-space">Business Space</button>

				<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
					data-filter=".wall-space">Wall Space</button>

				<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
					data-filter=".bathroom">Bathrooms</button>

				<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
					data-filter=".kitchen">Kitchen</button>

				<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
					data-filter=".furniture">Furniture</button>

				<button class="stext-106 cl6 hov1 bor3 trans-04 m-r-32 m-tb-5"
					data-filter=".medical">Hospital</button>
			</div>
		</div>

		<div class="row isotope-grid">
			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item business-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/business_01.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item business-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/business_02.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item business-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/business_03.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item business-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/business_04.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item wall-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/wall_01.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item wall-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/wall_02.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item wall-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/wall_03.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div
				class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item wall-space">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/wall_04.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item bathroom">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/bath_01.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item bathroom">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/bath_02.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item bathroom">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/bath_03.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item bathroom">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/bath_04.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item kitchen">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/kitchen_01.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item kitchen">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/kitchen_02.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item kitchen">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/kitchen_03.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item kitchen">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/kitchen_04.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item furniture">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/furniture_01.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item furniture">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/furniture_02.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item furniture">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/furniture_03.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item furniture">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/furniture_04.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item medical">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/hospital_01.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>

			<div class="col-sm-6 col-md-4 col-lg-3 p-b-35 isotope-item medical">
				<!-- Block2 -->
				<div class="block2">
					<div class="block2-pic hov-img0" style="max-height: 150px;">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/application/hospital_02.jpg"
							alt="IMG-PRODUCT">
					</div>
				</div>
			</div>


		</div>


	</div>

</section>


<section class="bg0 p-t-75 p-b-120" id="installation">
	<div class="container">
		<div class="p-b-32">
			<h3 class="ltext-105 cl5 txt-center respon1">Installation</h3>
		</div>
		<div class="row p-b-148">
			<div class="col-md-7 col-lg-8">
				<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
					<h3 class="mtext-111 cl2 p-b-16">Easy & Long Lasting</h3>

					<p class="stext-113 cl6 p-b-26" style="text-align:justify; ">Most solid surface countertop
						materials can only be installed by installers licensed by the
						manufacturer or distributor. One of the main reasons is
						traditional solid surface sheets are fabricated by building up
						1/2-inch-thick materials with underlayment to create the
						appearance of thicker materials, then cutting and gluing-up a
						front edge, much in the same manner as a plastic laminate top over
						a plywood subsurface. Both procedures are labor intensive. However
						steps taken by professionals are most likely to be these and in
						the same sequence -
					
					
					<ul class="stext-113 cl6 p-b-26">
						<li>Remove the old surface</li>
						<li>Use transparent or semi transparent plastic sheet as a
							template and take measurements</li>
						<li>Use a fabrication platform to support the solid surface and
							then give it desired shape</li>
						<li>Cut the solid surface as per measurement and requirement</li>
						<li>Place the solid surface on the desired location. Use adhesive
							to keep the surface in place and apply generously at joints.</li>
					</ul>

					</p>

				</div>
			</div>

			<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
				<div class="how-bor1 ">
					<div class="hov-img0">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/installation.jpg"
							alt="IMG">
					</div>
				</div>
			</div>
		</div>
		</div>
		</section>
		
		
<section class="bg0 p-t-75 p-b-120" id="maintenance">
	<div class="container">

		<div class="p-b-10">
			<h3 class="ltext-105 cl5 txt-center respon1">Maintenance</h3>
		</div>

		<div class="row">
			<div class="order-md-2 col-md-7 col-lg-8 p-b-30">
				<div class="p-t-7 p-l-85 p-l-15-lg p-l-0-md">
					<h3 class="mtext-111 cl2 p-b-16">Cost effective</h3>

					<p class="stext-113 cl6 p-b-26" style="text-align:justify; ">The versatility and durability of
						solid surface countertops and other stuffs makes them popular with
						many homeowners as well as business, and the fact that they are
						low maintenance is another popular characteristic. When your solid
						surface counters have stains, cleaning requires a damp cloth for
						some stains and a mild mix of soap and water for more stubborn
						stains.</p>
					<p class="stext-113 cl6 p-b-26" style="text-align:justify; ">
					The material is highly heat resistant so you don't have to worry
					about even the extremest conditions you may be facing. Households,
					bathrooms, kitchens and even exteriors, Solid surface products from
					Reccorian will fit everywhere & anywhere. Fix it once and forget
					for at least 50 yrs, it will last more than you ever wished it to.
					This makes it cost effective in long run.
					</p>
				
				</div>
			</div>

			<div class="order-md-1 col-11 col-md-5 col-lg-4 m-lr-auto p-b-30">
				<div class="how-bor2">
					<div class="hov-img0">
						<img
							src="<?php echo base_url();  ?>assets/web_front/images/maintenance.jpg"
							alt="IMG">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
