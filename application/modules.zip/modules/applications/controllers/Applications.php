<?php
    class Applications extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('applications/applications_view');
        $this->load->view('template/footer');

    }
  }
?>