<?php

class Inventory extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->view_data = array();
      //  $this->load->model('invoice/M_invoice');
        $this->load->model('inventory/M_inventory');
     //   $this->load->model('users/M_users');
    }

    function display_items()
    {
        $this->load->library('session');
        $this->load->helper('url');
        if (! $this->session->userdata('user')) {
            redirect(base_url());
        } else {
            $this->view_data['category_types'] = $this->populate_model_select();
            
            $this->view_data['items'] = $this->M_inventory->get_all_items();
            $this->view_data['header'] = 'Products';
            $this->view_data['page_desc'] = 'List';
            $this->view_data['content_view'] = 'inventory/inventory_view';
            $this->template->admin_template($this->view_data);
        }
    }

    function populate_model_select()
    {
        $item_types = $this->M_inventory->get_category_types();
        $options = '';
        if (count($item_types)) {
            foreach ($item_types as $key => $value) {
                $options .= "<option value='{$value->category}'> {$value->category} </option>";
            }
        }
        return $options;
    }


    public function item_add()
    {
        $data = array(
            'srno' => $this->input->post('sr_num'),
            'category' => $this->input->post('item_model'),
            'name' => $this->input->post('item_name')            
        );
        $insert = $this->M_inventory->item_add($data);
        
        echo json_encode(array(
            "status" => TRUE
        ));
    }

    public function item_delete($id)
    {
        $this->M_inventory->delete_item_by_id($id);
        echo json_encode(array(
            "status" => TRUE
        ));
    }

    public function ajax_edit_item($id)
    {
        $data = array();
        $data['item'] = $this->M_inventory->get_item_by_id($id);
        echo json_encode($data);
    }

    public function item_update()
    {
        
        $data = array(
            'srno' => $this->input->post('sr_num'),
            'category' => $this->input->post('item_model'),
            'name' => $this->input->post('item_name')
        );
        
        $this->M_inventory->item_update(array(
            'srno' => $this->input->post('sr_num')
        ), $data);
        echo json_encode(array(
            "status" => TRUE
        ));
    }
}
?>