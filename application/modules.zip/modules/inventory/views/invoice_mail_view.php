<div class="box">
    <h3>Invoice # <?php echo $item->capital_price;  ?> </h3>

</div>
