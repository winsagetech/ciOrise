<?php
    
    class Our_services extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('our_services/our_services_view');
        $this->load->view('template/footer');

    }
  }
?>