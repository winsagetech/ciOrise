
	


      <!-- ========================  Home Slider ======================== -->
       
        <section id="page-home" class="header-content">

            <div class="owl-slider owl-slider-fullscreen">

                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_01.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">Hotel Furnishing</h2>
                            <!-- 
                            <div class="animated" data-animation="fadeInUp">
                                Modern & powerfull template. <br /> Clean design & reponsive
                                layout. Google fonts integration
                            </div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="https://themeforest.net/item/mobel-furniture-website-template/20382155" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>

                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_02.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">Paintings & Showpieces</h2>
                            <!-- 
                            <div class="animated" data-animation="fadeInUp">Unlimited Choices. Unbeatable Prices. Free Shipping.</div>
                            <div class="animated" data-animation="fadeInUp">Furniture category icon fonts!</div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="category.html" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>
                
                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_03.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">Banquet & Buffet</h2>
                            <!-- 
                            <div class="animated" data-animation="fadeInUp">Unlimited Choices. Unbeatable Prices. Free Shipping.</div>
                            <div class="animated" data-animation="fadeInUp">Furniture category icon fonts!</div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="category.html" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>

                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_04.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">
                                Modern Furnitures
                            </h2>
                            <!-- 
                            <div class="desc animated" data-animation="fadeInUp">
                                Combine with animate.css. Or just use your own!.
                            </div>
                            <div class="desc animated" data-animation="fadeInUp">
                                Bunch of typography effects.
                            </div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="https://themeforest.net/item/mobel-furniture-website-template/20382155" target="_blank" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>
                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_05.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">Living Room Furnitures</h2>
                            <!-- 
                            <div class="animated" data-animation="fadeInUp">Unlimited Choices. Unbeatable Prices. Free Shipping.</div>
                            <div class="animated" data-animation="fadeInUp">Furniture category icon fonts!</div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="category.html" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>
                
                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_06.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">Light Fittings</h2>
                            <!-- 
                            <div class="animated" data-animation="fadeInUp">Unlimited Choices. Unbeatable Prices. Free Shipping.</div>
                            <div class="animated" data-animation="fadeInUp">Furniture category icon fonts!</div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="category.html" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>

                <!-- === slide item === -->

                <div class="item" style="background: linear-gradient(rgba(0,0,0,.4), rgba(0,0,0,.4)), url(<?php echo base_url();  ?>assets/images/slides/slide_07.jpg); background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;">
                    <div class="box">
                        <div class="container text-center">
                            <h2 class="title animated h1" data-animation="fadeInDown">
                                Hotel Operations Items
                            </h2>
                            <!-- 
                            <div class="desc animated" data-animation="fadeInUp">
                                Combine with animate.css. Or just use your own!.
                            </div>
                            <div class="desc animated" data-animation="fadeInUp">
                                Bunch of typography effects.
                            </div>
                            <div class="animated" data-animation="fadeInUp">
                                <a href="https://themeforest.net/item/mobel-furniture-website-template/20382155" target="_blank" class="btn btn-clean">Explore</a>
                            </div>
                             -->
                        </div>
                    </div>
                </div>

            </div> <!--/owl-slider-->
        </section>
        
                <!-- ========================  Icons ======================== -->

        <section class="info-icons info-icons-frontpage">
            <div class="container">
                <div class="row">
                <div class="col-xs-6 col-md-3">
                        <figure>
                            <figcaption>
                                <span><i class="icon icon-users"></i></span>
                                <span>
                                    <strong>Right Network</strong>
                                    
                                </span>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="col-xs-6 col-md-3">
                        <figure>
                            <figcaption>
                                <span><i class="icon icon-gift"></i></span>
                                <span>
                                    <strong>Right Product</strong>
                                    
                                </span>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="col-xs-6 col-md-3">
                        <figure>
                            <figcaption>
                                <span><i class="icon icon-calendar-full"></i></span>
                                <span>
                                    <strong>Right Time</strong>
                                    
                                </span>
                            </figcaption>
                        </figure>
                    </div>
                    <div class="col-xs-6 col-md-3">
                        <figure>
                            <figcaption>
                                <span><i class="icon icon-thumbs-up"></i></span>
                                <span>
                                    <strong>Right Price</strong>
                                    
                                </span>
                            </figcaption>
                        </figure>
                    </div>
                    
                </div>
            </div>
        </section>
        
        

		<!-- ========================  Blog Block ======================== -->

        <section class="blog" id="page-ideas">

            <div class="container">

                <!-- === blog header === -->

                <header>
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8 text-center">
                            <h2 class="title">PRODUCT CATEGORIES</h2>
                            <div class="text">
                                <p>Check out our great collection</p>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="row">

                    <!-- === blog item === -->
                <?php $a=1;
                 foreach($categories as $category) { if($a<20) { ?>
                    <div class="col-sm-4">
                        <article>
                             <a href="<?php echo base_url();  ?>blog/goto_blog/<?php echo $category->id;?>">
                              <div class="image" style="background-image:url(<?php echo base_url();  ?>upload/cats/<?php echo $category->image; ?>)">
                                    <img src="<?php echo base_url();  ?>upload/cats/<?php echo $category->image; ?>" alt="" />
                                </div>
                                <div class="entry entry-table">

                                    <div class="title">
                                        <h2 class="h5"> <?php echo $category->category; ?></h2>
                                    </div>
                                </div>
                                <div class="show-more">
                                    <span class="btn btn-main btn-block">Explore</span>
                                </div>
                            </a>
                        </article>
                    </div>
            <?php $a = $a+1;
        }
            else {
                break;
            } } ?>
                    
				<!-- 
                <div class="wrapper-more">
                    <a href="<?php echo base_url();  ?>blog" class="btn btn-main">View all posts</a>
                </div>
                 -->

            </div> <!--/container-->
        	</div>
        </section>



        <!-- ========================  Banner ======================== -->

        <section class="banner img" style="background-image:url(<?php echo base_url();  ?>assets/images/deal.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-md-offset-2 col-md-8 text-center">
                        <h2 class="title">The Best Deal Makers</h2>
                        <p>
                            We strive to offer the best professional services with competitive fees and a flexible fee structure. 
                            Most importantly, we ensure real value is added to your China business ventures & operations.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        


		<!-- ========================  Blog Block ======================== -->

        <section class="blog" id="page-ideas">

            <div class="container">

                <!-- === blog header === -->

                <header>
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8 text-center">
                            <h2 class="title">New Arrivals</h2>
                            <div class="text">
                                <p>Latest items added to our inventory</p>
                            </div>
                        </div>
                    </div>
                </header>

                <div class="row">

                    <!-- === blog item === -->
                       <!-- === blog item === -->
                <?php $a=1;
                 foreach($categories as $category) { if($a<4) { ?>
                    <div class="col-sm-4">
                        <article>
                             <a href="<?php echo base_url();  ?>blog/goto_blog/<?php echo $category->id;?>">
                              <div class="image" style="background-image:url(<?php echo base_url();  ?>upload/cats/<?php echo $category->image; ?>)">
                                    <img src="<?php echo base_url();  ?>upload/cats/<?php echo $category->image; ?>" alt="" />
                                </div>
                                <div class="entry entry-table">

                                    <div class="title">
                                        <h2 class="h5"> <?php echo $category->category; ?></h2>
                                    </div>
                                </div>
                                <div class="show-more">
                                    <span class="btn btn-main btn-block">Explore</span>
                                </div>
                            </a>
                        </article>
                    </div>
            <?php $a = $a+1;
        }
            else {
                break;
            } } ?>
                    
				<!-- 
                <div class="wrapper-more">
                    <a href="<?php echo base_url();  ?>blog" class="btn btn-main">View all posts</a>
                </div>
                 -->

            </div> <!--/container-->
        </section>
		

        <!-- ========================  Instagram ======================== 

        <section class="instagram" >



            <header>
                <div class="container">
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8 text-center">
                            <h2 class="h2 title">Follow us <i class="fa fa-instagram fa-2x"></i> Instagram </h2>
                            <div class="text">
                                <p>@idee.interiors</p>
                            </div>
                        </div>
                    </div>
                </div>
            </header>



            <div class="instabox">
            <a href="https://instawidget.net/v/user/idee.interiors" id="link-0dfb33b61efb5b7a656c9278e0532124015226959dca23d28399e955bff9423a">@idee.interiors</a>
            <script src="https://instawidget.net/js/instawidget.js?u=0dfb33b61efb5b7a656c9278e0532124015226959dca23d28399e955bff9423a&width=100%"></script>
                
            </div>
        </section>
		-->


        <!-- ========================  Contact ======================== -->

        <section id="page-contact" class="contact contact-single">

            <!-- === Goolge map === -->

            <div id="map"></div>

            <div class="container">

                <div class="row">

                    <div class="col-sm-10 col-sm-offset-1">

                        <div class="contact-block">

                            <div class="contact-info">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <figure class="text-center">
                                            <span class="icon icon-map-marker"></span>
                                            <figcaption>
                                                <strong>Where are we?</strong>
                                                <span>Rm 607, Block East, Tianan Development Building,<br>Hi-Tech Ecological Park, No.555 North Pan Yu Acenue,<br>Pan Yu District, Guangzhou, China.</span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="col-sm-6">
                                        <figure class="text-center">
                                            <span class="icon icon-phone"></span>
                                            <figcaption>
                                                <strong>Call us</strong>
                                                <span>
                                                    <strong>M</strong> +86-20-34368661 
                                                </span>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>

                            <div class="banner">
                                <div class="row">
                                    <div class="col-md-offset-1 col-md-10 text-center">
                                        <h2 class="title">Send an email</h2>
                                        <p>
                                            Hi There, We are looking forward to hearing from you. Please feel free to get in touch via the form below, we will get back to you as soon as possible.
                                        </p>

                                        <div class="contact-form-wrapper">

                                            <a class="btn btn-clean open-form" data-text-open="Contact us via form" data-text-close="Close form">Contact us via form</a>

                                            <div class="contact-form clearfix">
                                                <form action="#" method="post">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input type="text" value="" class="form-control" placeholder="Your name" required="required">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <input type="email" value="" class="form-control" placeholder="Your email" required="required">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">

                                                            <div class="form-group">
                                                                <input type="text" value="" class="form-control" placeholder="Subject" required="required">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <textarea class="form-control" placeholder="Your message" rows="10"></textarea>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12 text-center">
                                                            <input type="submit" class="btn btn-clean" value="Send message" />
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>


                    </div><!--col-sm-8-->
                </div> <!--/row-->
            </div><!--/container-->
        </section>

