<?php
    class Idee extends MY_Controller
	{
        function index()
        {	
            $this->load->model('idee/M_idee');
            $this->load->model('category/M_category');
            $this->load->model('blog/M_blog');
			$data['pages'] = $this->M_idee->get_all_pages();			
			$data['categories'] = $this->M_category->get_all_category();
			$data['blog'] = $this->M_blog->get_all_blog();

			
			$this->load->view('template/header', $data);
			$this->load->view('idee_view3',$data);
			$this->load->view('template/footer', $data);		
		}
 	 }
?>