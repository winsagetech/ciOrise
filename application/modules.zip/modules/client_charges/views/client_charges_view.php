<section class="main-header" style="background-image:url(<?php echo base_url();  ?>assets/images/blogs/header.jpg)">
            <header>
                <div class="container text-center">
                    <h1 class="h2 title">CLIENT CHARGES</h1>
                </div>
            </header>
</section>
        

<section class="history" id="page-about">
            <div class="container">

                <!-- === row item === -->

                <div class="row row-block">
                    <div class="col-md-12 history-desc">
        
                      <!-- Title -->
                        <h4 class="card-title" align="center"><strong>Charges Bear By Clients</strong></h4>
                        

                        <hr class="my-5">
 
                        <table class="table table-bordered">
                        <tbody>
                        <tr>
                        <td>HOTEL</td>
                        <td>AS PER ACTUAL</td>
                        </tr>
                        <tr>
                        <td>TAXI</td>
                        <td>AS PER ACTUAL ( FROM MORNING TILL NIGHT) PICKING UP OUR PEOPLE TO DROP THEM BACK </td>
                        </tr>
                        <tr>
                        <td>GOODS MIXING CHARGES</td>
                        <td>AS PER ACTUAL ( BASED ON DIFFERENT CITY GOODS PUT IN ONE CONTAINER </td>
                        </tr>
                        <tr>
                        <td>LOADING CHARGES</td>
                        <td> AS PER ACTUAL ( WE HIRE SPECIAL LABOR TO LOAD THE GOODS IN CONTAINER FOR SAFEGUARD OF THE GOODS FROM DAMAGE & OTHER LOSES) </td>
                        </tr>
                        <tr>
                        <td>FOB, TRUCKING, CUSTOMS & DOCS CHARGES (TO MAKE FOB)</td>
                        <td>AS PER ACTUAL </td>
                        </tr>
                        <tr>
                        <td>SEA FREIGHT</td>
                        <td> AS PER ACTUAL</td>
                        </tr>
                        <tr>
                        <td>INSURANCE</td>
                        <td>AS PER ACTUAL</td>
                        </tr>
                        <tr>
                        <td>OTHERS</td>
                        <td>BASED ON CLIENT REQUIREMENTS</td>
                        </tr>
                        </tbody>
                        </table>

                    </div>
                </div>
                
            </div>
</section>