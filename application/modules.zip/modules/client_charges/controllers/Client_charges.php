<?php
    
    class Client_charges extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('client_charges/client_charges_view');
        $this->load->view('template/footer');

    }
  }
?>