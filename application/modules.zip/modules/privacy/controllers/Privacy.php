<?php
class Privacy extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('privacy/privacy_view');
        $this->load->view('template/footer');
        
    }
}
?>