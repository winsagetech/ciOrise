 <style type="text/css">

    .img{
        opacity: 0.8;
    }

</style>

 <div class="page-loader"></div>        <!-- ========================  Main header ======================== -->

         <section class="main-header" style="background-image:url(<?php echo base_url();  ?>assets/mobel/assets/images/ourstory_image4.jpg)">
            <header>
                <div class="container text-center">
                    <h2 class="h2 title">About Us</h2>
                </div>
            </header>
        </section>

        <!-- ================== Intro section default ================== -->

        <section class="our-team">
            <div class="container">

                <!-- === Our team header === -->

                <div class="row">
                    <div class="col-md-offset-2 col-md-8 text-center">
                        <h1 class="h2 title">OUR OUTSTANDING TEAM</h1>
                        <div class="text">
                            <p>Our team is our greatest asset. From delivering a better design to understanding our client in the best way, we make your home a beautiful place to live.</p>
                            <br>
                        </div>
                    </div>
                </div>

                <!-- === Our team === -->

                <div class="team">

                    <div class="row">



                        <!-- === team member === -->

                        <div class="col-sm-4">
                            <article>
                                <div class="details details-text">
                                    <div class="inner">
                                        <h3 class="title">ROHIT RANE</h3>
                                    </div>
                                </div>
                                <div class="image">
                                    <img src="<?php echo base_url();  ?>assets/mobel/assets/images/team.png" alt="" />
                                </div>
                                <div class="details details-social">
                                    <div class="inner">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-google-plus"></i></a>
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        <!-- === team member === -->

                        <div class="col-sm-4">
                            <article>
                                <div class="details details-text">
                                    <div class="inner">
                                        <h3 class="title">PRACHIE CHHABRA</h3>
                                    </div>
                                </div>
                                <div class="image">
                                    <img src="<?php echo base_url();  ?>assets/mobel/assets/images/team.png" alt="" />
                                </div>
                                <div class="details details-social">
                                    <div class="inner">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-google-plus"></i></a>
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        <!-- === team member === -->

                        <div class="col-sm-4">
                            <article>
                                <div class="details details-text">
                                    <div class="inner">
                                        <h3 class="title">PRAKASH CHHABRA</h3>
                                    </div>
                                </div>
                                <div class="image">
                                    <img src="<?php echo base_url();  ?>assets/mobel/assets/images/team.png" alt="" />
                                </div>
                                <div class="details details-social">
                                    <div class="inner">
                                        <a href="#"><i class="fa fa-facebook"></i></a>
                                        <a href="#"><i class="fa fa-twitter"></i></a>
                                        <a href="#"><i class="fa fa-google-plus"></i></a>
                                        <a href="#"><i class="fa fa-linkedin"></i></a>
                                    </div>
                                </div>
                            </article>
                        </div>

                    </div> <!--/row-->
                    <br>
                    <!-- === button more === -->

                    <div class="wrapper-more">
                        <a href="<?php echo base_url();  ?>contact_us" class="btn btn-clean-dark">Contact us</a>
                    </div>
                </div> <!--/team-->
            </div>
        </section>

        <!-- ================== Banner ================== -->

        <section class="banner" style="background-image:url(<?php echo base_url();  ?>assets/mobel/assets/images/ourstory_image6.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-md-offset-2 col-md-8 text-center">
                        <h1 class="h2 title">We love our work</h1>
                        <div class="text" align="justify">
                            <p>
                            IDEE - Make Your Home more Beautiful than You can Imagine<br><br>
                            Idea, Design, Establishment & Exclusivity<br><br>
                            IDEE is an upcoming interior designer and design-and-build establishment, fueled by innovation and interaction.<br><br>

                            We provide complete 360 degree design services beginning with an initial design concept, the installation and the final detailing to give a luxurious ambience to residential projects.<br><br>

                            We believe that your home defines who you are and vice versa. The basic brand ideology behind IDEE is Idea, Design, Establishment and Exclusivity.<br><br>

                            "Everything begins with an idea. With a great Idea comes a great design. An awesome design with a perfect Establishment creates an aura of exclusivity."<br><br>

                            So an amalgamation of IDEE along with your individual style and panache, you can transform your home to heaven.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ========================  Cards ======================== -->

        <section class="cards">

            <!-- === cards header === -->

            <header>
                <div class="row">
                    <div class="col-md-offset-2 col-md-8 text-center">
                        <h2 class="title">BRANDS WITH US</h2>
                        <div class="text">
                            <p>We extract the essence of the classic</p>
                        </div>
                    </div>
                </div>
            </header>

            <div class="container">
                <div class="row">

                    <!-- === item === -->
                     <div class="col-md-4 col-xs-6">
                    <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image1.jpeg" alt="" width="360" />
                                </div>

                     </div>
                 </div>
                      <div class="col-md-4 col-xs-6">
                     <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image2.jpg" alt="" width="360" />
                                </div>

                     </div>
                 </div>
                  <div class="col-md-4 col-xs-6">
                     <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image3.jpeg" alt="" width="360" />
                                </div>

                     </div>
                 </div>
                  <div class="col-md-4 col-xs-6">
                     <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image4.jpeg" alt="" width="360" />
                                </div>

                     </div>
                 </div>
                  <div class="col-md-4 col-xs-6">
                     <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image5.jpeg" alt="" width="360" />
                                </div>

                     </div>
                 </div>
                  <div class="col-md-4 col-xs-6">
                     <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image6.jpeg" alt="" width="360" />
                                </div>

                     </div>
                 </div>
                  <div class="col-md-4 col-xs-6">
                     <div class="figure-grid">
                                <div class="image">
                                 <img src="<?php echo base_url();  ?>assets/mobel/assets/images/brand_image7.jpeg" alt="" width="360" />
                                </div>

                     </div>
                 </div>

                </div> <!--/row-->

            </div> <!--/container-->
        </section>

        <!-- ========================  Banner ======================== -->

        <section class="banner" style="background-image:url(<?php echo base_url();  ?>assets/mobel/assets/images/ourstory_image7.jpg)">
            <div class="container">
                <div class="row" align="justify">
                    <div class="col-md-offset-1 col-md-10 text-center">
                        <h2 class="title">Our story</h2>
                        <p>
                            We believe in creativity as one of the major forces of progress. With this idea, we traveled throughout<br>
                            country to find exceptional artisans and bring their unique handcrafted objects to connoisseurs
                            everywhere.
                        </p>
                        <p>
                            You've finally reached this point in your life- you've bought your first home, moved into your very own<br>
                            apartment, moved out of the dorm room or you're finally downsizing after all of your kids have left the nest.
                        </p>
                    </div>
                </div>
            </div>
        </section>
