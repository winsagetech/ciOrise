<?php
    
    class Our_company extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('our_company/our_company_view');
        $this->load->view('template/footer');

    }
  }
?>