<?php
    
    class About_shipping extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('about_shipping/about_shipping_view');
        $this->load->view('template/footer');

    }
  }
?>