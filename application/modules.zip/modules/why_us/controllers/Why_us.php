<?php
    
    class Why_us extends MY_Controller {
    function index()
    {
        
        $this->load->view('template/header');
        $this->load->view('why_us/why_us_view');
        $this->load->view('template/footer');

    }
  }
?>